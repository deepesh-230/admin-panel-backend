import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class EnquiriesService {
  constructor(private prisma: PrismaService) {}

  async findAll(searchQuery?: string) {
    if (searchQuery) {
      return this.prisma.enquiry.findMany({
        where: {
          OR: [
            { product: { contains: searchQuery } },
            { name: { contains: searchQuery } },
            { email: { contains: searchQuery } },
            { category: { contains: searchQuery } },
          ]
        },
        orderBy: { sNo: 'asc' }
      });
    }
    return this.prisma.enquiry.findMany({
      orderBy: { sNo: 'asc' }
    });
  }
}
