import { Controller, Get, Query } from '@nestjs/common';
import { EnquiriesService } from './enquiries.service';

@Controller('enquiries')
export class EnquiriesController {
  constructor(private readonly enquiriesService: EnquiriesService) {}

  @Get()
  findAll(@Query('search') search?: string) {
    return this.enquiriesService.findAll(search);
  }
}
