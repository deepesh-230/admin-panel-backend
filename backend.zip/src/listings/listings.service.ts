import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class ListingsService {
  constructor(private prisma: PrismaService) {}

  async findAll(searchQuery?: string) {
    if (searchQuery) {
      return this.prisma.listing.findMany({
        where: {
          OR: [
            { product: { contains: searchQuery } },
            { email: { contains: searchQuery } },
            { category: { contains: searchQuery } },
          ]
        },
        orderBy: { sNo: 'asc' }
      });
    }
    return this.prisma.listing.findMany({
      orderBy: { sNo: 'asc' }
    });
  }

  async updateStatus(id: string, status: boolean) {
    const listing = await this.prisma.listing.findUnique({ where: { id } });
    if (!listing) {
      throw new NotFoundException(`Listing with ID ${id} not found`);
    }
    return this.prisma.listing.update({
      where: { id },
      data: { status },
    });
  }
}
