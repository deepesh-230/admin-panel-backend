import { Controller, Get, Patch, Param, Body, Query } from '@nestjs/common';
import { ListingsService } from './listings.service';

@Controller('listings')
export class ListingsController {
  constructor(private readonly listingsService: ListingsService) {}

  @Get()
  findAll(@Query('search') search?: string) {
    return this.listingsService.findAll(search);
  }

  @Patch(':id/status')
  updateStatus(
    @Param('id') id: string,
    @Body('status') status: boolean,
  ) {
    return this.listingsService.updateStatus(id, status);
  }
}
